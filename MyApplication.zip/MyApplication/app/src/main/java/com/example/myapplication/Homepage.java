package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Homepage extends AppCompatActivity implements View.OnClickListener {

    ImageView milliontoone,girlinred,concreterose,charmedwife;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);

        milliontoone=(ImageView)findViewById(R.id.milliontoone);
        girlinred=(ImageView)findViewById(R.id.girlinred);
        concreterose=(ImageView)findViewById(R.id.concreterose);
        charmedwife=(ImageView)findViewById(R.id.charmedwife);

        milliontoone.setOnClickListener(this);
        girlinred.setOnClickListener(this);
        concreterose.setOnClickListener(this);
        charmedwife.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent BookDetails = new Intent(Homepage.this, com.example.myapplication.BookDetails.class);

        switch (view.getId()){
            case R.id.milliontoone:
                BookDetails.putExtra("name","milliontoone");

                startActivity(BookDetails);

            break;

            case R.id.girlinred:
                BookDetails.putExtra("name","girlinred");

                startActivity(BookDetails);

            break;

            case R.id.concreterose:
                BookDetails.putExtra("name","concreterose");

                startActivity(BookDetails);

            break;

            case R.id.charmedwife:
                BookDetails.putExtra("name","charmedwife");

                startActivity(BookDetails);
        }
    }
}