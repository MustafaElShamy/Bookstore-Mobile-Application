package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class NewDatabaseUpdate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_database_update);
        String name = getIntent().getStringExtra("NAME");
        String author = getIntent().getStringExtra("AUTHOR");
        String year = getIntent().getStringExtra("YEAR");
        String price = getIntent().getStringExtra("PRICE");
        String copies = getIntent().getStringExtra("COPIES");
        String description = getIntent().getStringExtra("DESCRIPTION");
        EditText nameE = (EditText)findViewById(R.id.editName6);
        EditText authorE = (EditText)findViewById(R.id.editAuthor6);
        EditText yearE = (EditText)findViewById(R.id.yearEdit6);
        EditText priceE = (EditText)findViewById(R.id.priceEdit6);
        EditText copiesE = (EditText)findViewById(R.id.copiesEdit6);
        EditText descriptionE = (EditText)findViewById(R.id.descEdit6);
        nameE.setText(name);
        authorE.setText(author);
        yearE.setText(year);
        priceE.setText(price);
        copiesE.setText(copies);
        descriptionE.setText(description);

    }

    public void updateDatabase(View view)
    {
        EditText nameE = (EditText)findViewById(R.id.editName6);
        EditText authorE = (EditText)findViewById(R.id.editAuthor6);
        EditText yearE = (EditText)findViewById(R.id.yearEdit6);
        EditText priceE = (EditText)findViewById(R.id.priceEdit6);
        EditText copiesE = (EditText)findViewById(R.id.copiesEdit6);
        EditText descriptionE = (EditText)findViewById(R.id.descEdit6);
        String name = nameE.getText().toString();
        String author = authorE.getText().toString();
        String year = yearE.getText().toString();
        String price = priceE.getText().toString();
        String copies = copiesE.getText().toString();
        String description = descriptionE.getText().toString();
        String ID = getIntent().getStringExtra("ID");

        NewDatabase bookhelper = new NewDatabase(getApplicationContext());
        bookhelper.updatebooks(Integer.parseInt(ID),name,author,year,price,copies,description);
        Toast.makeText(getApplicationContext(),"Record Updated!",Toast.LENGTH_SHORT).show();



    }
}