package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;


public class BookDetails extends AppCompatActivity {

    ImageView product_image;

    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);

        product_image=(ImageView)findViewById(R.id.bookimage);

        bundle= getIntent().getExtras();

        if (bundle !=null){
            String name=bundle.getString("name");

            setUp(name);
        }
    }

    private void setUp(String name) {
        ListView bookinfo = (ListView)findViewById(R.id.bookinfo);
        ListView desclist = (ListView)findViewById(R.id.desclist);
        ArrayAdapter dataadapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1);
        ArrayAdapter dataadapter2 = new ArrayAdapter(this,android.R.layout.simple_list_item_1);
        bookinfo.setAdapter(dataadapter);
        desclist.setAdapter(dataadapter2);
        NewDatabase infohelper = new NewDatabase(this);

        if(name.equals("milliontoone")){
            product_image.setImageResource(R.drawable.million_to_one);
            Cursor cursor = infohelper.fetchcertainbooks(2);
            while(!cursor.isAfterLast())
            {
                dataadapter.add(cursor.getString(0));
                dataadapter.add(cursor.getString(1));
                dataadapter.add(cursor.getString(2));
                dataadapter.add(cursor.getString(3));
                dataadapter.add(cursor.getString(4));
                dataadapter2.add(cursor.getString(5));
                cursor.moveToNext();
            }
        }

        else if(name.equals("girlinred")){
            product_image.setImageResource(R.drawable.thegirlinred);
            Cursor cursor = infohelper.fetchcertainbooks(3);
            while(!cursor.isAfterLast())
            {
                dataadapter.add(cursor.getString(0));
                dataadapter.add(cursor.getString(1));
                dataadapter.add(cursor.getString(2));
                dataadapter.add(cursor.getString(3));
                dataadapter.add(cursor.getString(4));
                dataadapter2.add(cursor.getString(5));
                cursor.moveToNext();
            }
        }

        else if(name.equals("concreterose")){
            product_image.setImageResource(R.drawable.concrete_rose);
            Cursor cursor = infohelper.fetchcertainbooks(4);
            while(!cursor.isAfterLast())
            {
                dataadapter.add(cursor.getString(0));
                dataadapter.add(cursor.getString(1));
                dataadapter.add(cursor.getString(2));
                dataadapter.add(cursor.getString(3));
                dataadapter.add(cursor.getString(4));
                dataadapter2.add(cursor.getString(5));
                cursor.moveToNext();
            }

        }

        else if(name.equals("charmedwife")){
            product_image.setImageResource(R.drawable.charmed_wife);
            Cursor cursor = infohelper.fetchcertainbooks(5);
            while(!cursor.isAfterLast())
            {
                dataadapter.add(cursor.getString(0));
                dataadapter.add(cursor.getString(1));
                dataadapter.add(cursor.getString(2));
                dataadapter.add(cursor.getString(3));
                dataadapter.add(cursor.getString(4));
                dataadapter2.add(cursor.getString(5));
                cursor.moveToNext();
            }
        }
    }

}