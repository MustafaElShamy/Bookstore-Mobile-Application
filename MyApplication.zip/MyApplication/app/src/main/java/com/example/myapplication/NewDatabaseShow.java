package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class NewDatabaseShow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_database_show);
        ListView booklist = (ListView)findViewById(R.id.ListView2);
        ArrayAdapter dataadapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1);
        booklist.setAdapter(dataadapter);
        NewDatabase bookhelper = new NewDatabase(this);
        Cursor cursor = bookhelper.fetchallbooks();
        while(!cursor.isAfterLast())
        {
            dataadapter.add(cursor.getString(0));
            cursor.moveToNext();
        }
        booklist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                NewDatabase celebhelper = new NewDatabase(getApplicationContext());
                Cursor cursor =celebhelper.fetchcertainbooks(position+1);
                String name = cursor.getString(0);
                String author = cursor.getString(1);
                String year = cursor.getString(2);
                String price = cursor.getString(3);
                String copies = cursor.getString(4);
                String description = cursor.getString(5);
                Intent I = new Intent(getBaseContext(),NewDatabaseUpdate.class);
                I.putExtra("NAME",name);
                I.putExtra("AUTHOR",author);
                I.putExtra("YEAR",year);
                I.putExtra("PRICE",price);
                I.putExtra("COPIES",copies);
                I.putExtra("DESCRIPTION",description);
                I.putExtra("ID",Integer.toString(position+1));

                startActivity(I);


            }
        });
    }
}