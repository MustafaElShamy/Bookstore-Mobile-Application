package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class NewDatabaseAddBook extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_database_add_book);
    }

    public void createnewbook(View view){
        EditText name = (EditText)findViewById(R.id.editName5);
        EditText author = (EditText)findViewById(R.id.editAuthor5);
        EditText year = (EditText)findViewById(R.id.yearEdit5);
        EditText price = (EditText)findViewById(R.id.priceEdit5);
        EditText copies = (EditText)findViewById(R.id.copiesEdit5);
        EditText description = (EditText)findViewById(R.id.descEdit5);
        NewDatabase bookhandler = new NewDatabase(this);
        bookhandler.createnewbook(name.getText().toString(),author.getText().toString(),year.getText().toString(),price.getText().toString(),copies.getText().toString(),description.getText().toString());
        Toast.makeText(getApplicationContext(),"Book Added!",Toast.LENGTH_SHORT).show();
    }
    public void show(View view){
        Intent I = new Intent(getBaseContext(),NewDatabaseShow.class);
        startActivity(I);
    }
}
