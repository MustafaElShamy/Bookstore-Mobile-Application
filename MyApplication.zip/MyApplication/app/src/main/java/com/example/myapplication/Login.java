package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Login extends AppCompatActivity {
    public void signin(View view)
    {
        Intent I = new Intent(getBaseContext(), Homepage.class);
        startActivity(I);
    }

    public void admin(View view)
    {
        Intent I = new Intent(getBaseContext(), NewDatabaseAddBook.class);
        startActivity(I);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }
}