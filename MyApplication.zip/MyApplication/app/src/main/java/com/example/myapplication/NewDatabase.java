package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class NewDatabase extends SQLiteOpenHelper {
    static String databasename = "NewBookDatabase";
    SQLiteDatabase newbooksdatabase;
    public NewDatabase(Context context) {
        super(context, databasename, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table newbooks(id integer primary key,"
                +"name text not null,"+"author text not null,"+"year text not null,"+"price text not null,"+"copies text not null,"+"description text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists newbooks");
        onCreate(db);
    }
    public void createnewbook(String name,String author,String year,String price, String copies, String description)
    {
        ContentValues row = new ContentValues();
        row.put("name",name);
        row.put("author",author);
        row.put("year",year);
        row.put("price",price);
        row.put("copies",copies);
        row.put("description",description);
        newbooksdatabase = getWritableDatabase();
        newbooksdatabase.insert("newbooks",null,row);
        newbooksdatabase.close();

    }

    public Cursor fetchallbooks()
    {
        String [] columns ={"name","author","year","price","copies","description","id"};
        newbooksdatabase = getReadableDatabase();
        Cursor cursor=newbooksdatabase.query("newbooks", columns,null,null,null,null,null);

        if(cursor!=null) {
            cursor.moveToFirst();
        }
        newbooksdatabase.close();
        return cursor;
    }

    public Cursor fetchcertainbooks(int pos) {
        newbooksdatabase = getReadableDatabase();
        String[] rowdetails = {"name","author","year","price","copies","description","id"};
        Cursor cursor = newbooksdatabase.query("newbooks", rowdetails, "id = ?", new String[]{Integer.toString(pos)}, null, null, null);
        if (cursor != null) {
            //get the first record
            cursor.moveToFirst();
        }
        return cursor;
    }


    public void updatebooks(int id , String name, String author,String year,String price, String copies, String description)
    {
        ContentValues row = new ContentValues();
        row.put("name",name);
        row.put("author",author);
        row.put("price",price);
        row.put("copies",copies);
        row.put("description",description);
        newbooksdatabase = getWritableDatabase();

        newbooksdatabase.update("newbooks",row,"id = ?",new String[] {Integer.toString(id)});

    }

}